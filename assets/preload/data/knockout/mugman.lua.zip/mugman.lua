
function onCreate()
     makeAnimatedLuaSprite('mugman', 'characters/Mugman Fucking dies', 2350, 1400)
     addAnimationByPrefix('mugman', 'helo', 'Mugman instance 1', 24, false)
     addAnimationByPrefix('mugman', 'boom', 'MUGMANDEAD YES instance 1', 24, false)
     addLuaSprite('mugman', true) 
     setProperty('mugman.alpha', 0)
     makeAnimatedLuaSprite('hadoken', 'bull/Cuphead Hadoken', 800, 1350)
     addAnimationByPrefix('hadoken', 'tween', 'Hadolen instance 1', 24, true)
     addAnimationByPrefix('hadoken', 'boom', 'BurstFX instance 1', 24, false)
     
     setProperty('hadoken.alpha', 0)
     candodge = false;
     dodged = false;
     ok = false;

end

function onEvent(name, value1, value2) 
	if name == 'mugman' then
	    setProperty('mugman.alpha', 1)
	    objectPlayAnimation('mugman', 'helo', false)  
    end
end
function onUpdate()  
     if candodge == true and keyPressed('down') then
         dodged = true
         candodge = false
         characterPlayAnim('boyfriend', 'dodge', false) 
     end
     
     if getProperty('hadoken.x') == 1500 and dodged == true then 
           dodged = false 
           objectPlayAnimation('hadoken', 'boom', false) 
           objectPlayAnimation('mugman', 'boom', false) 
           doTweenX('ae', 'hadoken', 3000, 1.1, 'linear') 
    elseif getProperty('hadoken.x') == 1500 and dodged == false then
           setProperty('health', -1)
       end
end

function onTweenCompleted(t)
     if t == 'ae' then
        removeLuaSprite('hadoken', false)
     end
end 